<?php

return array(
	'Hello {name}, Welcome to use PhalApi!' => 'Hello {name}, Welcome to use PhalApi!',
    'user not exists' => 'user not exists',
);
