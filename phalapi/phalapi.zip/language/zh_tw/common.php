<?php

return array(
	'Hi {name}, welcome to use PhalApi!' => '{name}您好，歡迎使用PhalApi！',
	'user not exists' => '用戶不存在',
);
