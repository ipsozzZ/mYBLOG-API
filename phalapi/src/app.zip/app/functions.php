<?php
namespace App;

function hello() {
    return 'Hey, man~';
}
